

disp ('executing gpml startup script...')
mydir = fileparts (mfilename ('fullpath'));                 
addpath (mydir)
dirs = {'cov','inf','mean','util'};           
for d = dirs, addpath (fullfile (mydir, d{1})), end
dirs = {{'util','minfunc'},{'util','minfunc','compiled'}};    
for d = dirs, addpath (fullfile (mydir, d{1}{:})), end
addpath([mydir,'/util/sparseinv'])
















