function [SAGGPR_YPRED,SAGGPR_VAR]=SAGGPR(Xtr,Ytr,Xqu,c)

% INPUTS:
% Xtr: Input data matrix. Rows are observations, Columns are variables.
% Ytr: Response variable.
% Xqu: Query input variable.
% c:   Scalar value.(optional, DEFAULT = 0.001)

% OUTPUTS:
% SAGGPR_YPRED: Predicted response variable for Xqu. 
% SAGGPR_VAR: Identification results of important factors.


if ~exist('c')
    c = 0.001;
end
covfunc = {'covSEiso'};
meanfunc = @meanZero;
inffunc = @infTaylor;
likfunc = {@likExpo_generic, @likExPoisson};
nhyp = eval(feval(covfunc{:}));
inithyp.cov = zeros(nhyp,1);
nlik = eval(feval(likfunc{:}));
inithyp.lik = zeros(nlik,1);
hyp = minimize(inithyp, @gp, -200, inffunc, meanfunc, covfunc, likfunc, Xtr,Ytr);
[SAGGPR_YPRED] = gp(hyp, inffunc, meanfunc, covfunc, likfunc, Xtr,Ytr, Xqu);
for i=1:size(Xtr,1)
    for j=1:size(Xtr,1)
        KK(i,j) = (exp(hyp.cov(2)))^2* exp(-0.5*norm(Xtr(i,:)-Xtr(j,:))^2/(exp(hyp.cov(1)))^2 );
        KK(j,i) = KK(i,j);
    end
end
ww=1./(Ytr+c);
WW=diag(ww);
AA=inv(KK+WW);
tt=log(Ytr+c)-(c.*ww);
alphaAt=AA*tt;
for jj=1:size(Xtr,2) 
    sumj2=0; 
    for qq=1:size(Ytr,1)
        sumj1=0;
        for pp=1:size(Ytr,1)
            kkqqpp=KK(pp,qq);
            sumj1= sumj1+((alphaAt(pp)*(Xtr(pp,jj)-Xtr(qq,jj)))./(exp(hyp.cov(1)))^2)*kkqqpp;
        end
        sumj2=sumj2+sumj1^2;
    end
    senjsum(jj)=sumj2/size(Ytr,1);
    clear kkqqpp;
    clear sumj1;
    clear sumj2;
end
SAGGPR_VAR=senjsum./sum(senjsum);
end

%---------------------------------------------------