%%% compute EP moments using adaptive quadrature %%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Moments and log marginals for EP:
%      log marginal : lZ = log int p(y|eta)G(eta,mu,s2)deta
%      moments of q : q(eta)=p(y|eta)G(eta,mu,s2)/Z
%
% Also used to compute predictive log-likelihoods (y can be a matrix)
%
% lf -- expo family structure
% y  -- [N x ?]  - data points [N x 1], or target predictions [N x ny]
% mu -- [N x 1]  - posterior means
% s2 -- [N x 1]  - posterior variances
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

function [lZ, mu_moment, var_moment] = EPmomentsGaussQuad(lf, y, mu, s2)
% constants for adaptive quadrature
persistent weight_point;
numW_P = 20;
nanwarn = 0;
infwarn = 0;
pinfwarn = 0;
% % % % weight_point = cell(numW_P, 1);
% % % % weight_point{2, 1} = [-1, 1; 1/2, 1/2];
% % % % % weight_point{3, 1} = [-sqrt(3), 0, sqrt(3); 1/6, 2/3, 1/6];
% % % % weight_point{3, 1} = [-0.5*sqrt(3), 0, 0.5*sqrt(3); 1/3, 1/3, 1/3];
% % % % weight_point{4, 1} = [-sqrt(3+sqrt(6)), -sqrt(3-sqrt(6)), sqrt(3-sqrt(6)), sqrt(3+sqrt(6));
% % % %                       1/(4*(3+sqrt(6))), 1/(4*(3-sqrt(6))), 1/(4*(3-sqrt(6))), 1/(4*(3+sqrt(6)))];
if size(weight_point, 2) ~= numW_P
   weight_point = getP_W(numW_P);
end
numy = size(y,2);  % number of y per test point
numt = size(y,1);  % number of test points

% initialize storage
lZ = zeros(size(y));
if (nargout>1)
  mu_moment = zeros(size(y));
  if (nargout>2)
    var_moment = zeros(size(y));
  end
end

for i = 1:numt
  if (s2(i) <= 0)
    % check for zero variance, i.e., N(eta,mu,s2) is a delta function
    lZ(i,:) =  logp_and_d(lf, y(i,:), mu(i));
    if (nargout>1)
      mu_moment(i)  = mu;
      if (nargout>2)
	var_moment(i) = 0;
      end
    end
  else  
    tmplZ = zeros(numW_P, numy);  
    for j = 1 : numy
       tmplZ(:, j) = logp_and_d(lf, y(i, j), mu(i) + weight_point(1, :)'*sqrt(s2(i)));
% % %        largeIdx = find(tmplZ(:, j) < -45);
% % %        if ~isempty(largeIdx)
% % %          tmplZ(largeIdx, j) = -45;
% % %        end
        % change NaNs to -inf (usually this is from: inf-inf)
        iinn = find(isnan(tmplZ(:, j)));
        if ~isempty(iinn)
          tmplZ(iinn, j) = -inf;
          nanwarn = nanwarn + length(iinn);
        end
        % change +inf to -inf (more instabilities)
        % in general we should not have log(p) = inf
        iinn = find(isinf(tmplZ(:, j)) .* (tmplZ(:, j)>0));
        if ~isempty(iinn)
          tmplZ(iinn, j) = -inf;
          pinfwarn = pinfwarn+length(iinn);
        end
    
       tmplZ(:, j) = exp(tmplZ(:, j)) .* weight_point(2, :)';
    end
    
    lZ(i, :) =  log(sum(tmplZ));
    % check for lZ == -inf
    ii = find(isinf(lZ(i,:)));
    if ~isempty(ii)
      % lpg is too small, so try logtrick
      tmp = logtrick(tmplZ(:,ii));
      lZ(i,ii) = tmp + log(eta(2)-eta(1));        % assumes equal spacing
      infwarn = infwarn + length(ii);
    end
    
    if (nargout>1)
      % moment computations cannot handle more than one y per test point
      % in general, this is not currently needed.
      if (numy ~= 1)
	   error('cannot compute moments for more than 1 y!')
      end      
      tmplZ = tmplZ ./ repmat(sum(tmplZ), numW_P, 1);
      
      mu_moment(i, :) = mu(i) + sqrt(s2(i)) * weight_point(1, :) * tmplZ;
      
      % variance of q
      if (nargout>2)
	%fun_value = (eta-mu_moment(i)).^2 .* q;
	%var_moment(i) = trapz(eta, fun_value);
	   var_moment(i, :) = s2(i) * ((weight_point(1, :)).^2 * tmplZ - (weight_point(1, :) * tmplZ).^2);
      end
    end
  end
end

if (nanwarn > 0)
  fprintf('warning EPmomentsNumInt: lpg: replaced %d NaNs with -infs\n', nanwarn);
end
if (pinfwarn > 0)
  fprintf('warning EPmomentsNumInt: lpg: replaced %d inf with -infs\n', ...
	  pinfwarn);
end
if (infwarn > 0)
  fprintf('warning EPmomentsNumInt: lZ: used log-trick %d times\n', infwarn);
end

if (nargout>1) && any(isnan(mu_moment)) 
  warning('NaN mu');
  keyboard
end
if (nargout>2) && any(isnan(var_moment)) 
  warning('NaN var');
  keyboard
end
