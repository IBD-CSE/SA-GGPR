%%% compute EP derivatives using Gaussian Quadrature%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27
function [EVth, EVbth, EVdbhyp] = EPderivGaussQuad(lf, y, mu, s2)
persistent weight_point;

EVth  = zeros(size(y));
EVbth = zeros(size(y));

if (nargout == 3)
  EVdbhyp = zeros(size(y));
end

numW_P = 20;
if size(weight_point, 2) ~= numW_P
   weight_point = getP_W(numW_P);
end

nanwarn = 0;
infwarn = 0;
   
fth = @(eta) lf.theta(eta);
fbth = @(eta) lf.b(lf.theta(eta));

lZ = exp(EPmomentsGaussQuad(lf, y, mu, s2));

for i = 1:length(y)
   tmpx = mu(i) + weight_point(1, :)'*sqrt(s2(i));
   tmp2 = exp(logp_and_d(lf, y(i), tmpx));
   relth = weight_point(2, :)'.* fth(tmpx).*tmp2;
   relbth = weight_point(2, :)'.* fbth(tmpx).*tmp2;
   EVth(i) = sum(relth) / lZ(i);
   EVbth(i) = sum(relbth) / lZ(i);
   
   if (nargout == 3)
    % E[b'(theta(eta))]    -- b derivative wrt hyperparameter
    reldbhyp = weight_point(2, :)'.* lf.db_hyp(lf.theta(tmpx)).*tmp2;
    EVdbhyp(i) = sum(reldbhyp) / lZ(i);
   end
end

if (nanwarn > 0)
  fprintf('warning EPderivNumInt: lpg: replaced %d NaNs with -infs\n', nanwarn);
end
if (infwarn > 0)
  fprintf('warning EPderivNumInt: lZ: used log-trick %d times\n', infwarn);
end  
