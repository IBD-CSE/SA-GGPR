%%% compute EP derivatives using numerical integration %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

function [EVth, EVbth, EVdbhyp] = EPderivNumInt(lf, y, mu, s2)
% constants for numerical integration
% constants for numerical integration
NUMPOINTS = 1200;

% generate a standard Gaussian N(0,1) between -5 and 5 sigmas
persistent eta_standard N_standard delta_standard

%eta_standard = [];
if isempty(eta_standard)
  eta_standard = linspace(-5,5,NUMPOINTS);
  N_standard   = normpdf(eta_standard,0,1);
  delta_standard = eta_standard(2)-eta_standard(1);
end

EVth  = zeros(size(y));
EVbth = zeros(size(y));

if (nargout == 3)
  EVdbhyp = zeros(size(y));
end

nanwarn = 0;
infwarn = 0;
pinfwarn = 0;

Mstd   = sqrt(s2(:));
Meta   = bsxfun(@plus, bsxfun(@times, eta_standard, Mstd), mu(:));
Mdelta = delta_standard*Mstd;

% get logp.  each row of Mlogp is for one {m,v}
lpg = logp_and_d(lf, repmat(y(:), [1 NUMPOINTS]), Meta);

% change NaNs to -inf (usually this is from: inf-inf)
iinn = find(isnan(lpg));
if ~isempty(iinn)
  lpg(iinn) = -inf;
  nanwarn = nanwarn + length(iinn);
end
  
iinn = find(isinf(lpg) .* (lpg>0));
if ~isempty(iinn)
  lpg(iinn) = -inf;
  pinfwarn = pinfwarn+length(iinn);
end
    
lpg = exp(lpg);
    
MM = Mdelta ./ Mstd;
    
% logp(eta) * Normal(eta|m,v)
MlogpN = bsxfun(@times, lpg, N_standard);
lZ  = (sum(MlogpN,2) .* MM);
te = lf.theta(Meta);    
MlogpN = bsxfun(@times, te.*lpg, N_standard);
EVth(:)  = sum(MlogpN,2) .* MM./lZ(:);

MlogpN = bsxfun(@times, lf.b(te).*lpg, N_standard);
EVbth(:)  = sum(MlogpN,2) .* MM./lZ(:);
  
if (nargout == 3)
 % E[b'(theta(eta))]    -- b derivative wrt hyperparameter
 MlogpN = bsxfun(@times, lf.db_hyp(te).*lpg, N_standard);
 EVdbhyp(:) = sum(MlogpN,2) .* MM./lZ(:);
end
  
if (nanwarn > 0)
  fprintf('warning EPderivNumInt: lpg: replaced %d NaNs with -infs\n', nanwarn);
end
if (infwarn > 0)
  fprintf('warning EPderivNumInt: lZ: used log-trick %d times\n', infwarn);
end
