%%% compute EP moments using adaptive quadrature %%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Moments and log marginals for EP:
%      log marginal : lZ = log int p(y|eta)G(eta,mu,s2)deta
%      moments of q : q(eta)=p(y|eta)G(eta,mu,s2)/Z
%
% Also used to compute predictive log-likelihoods (y can be a matrix)
%
% lf -- expo family structure
% y  -- [N x ?]  - data points [N x 1], or target predictions [N x ny]
% mu -- [N x 1]  - posterior means
% s2 -- [N x 1]  - posterior variances
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

function [lZ, mu_moment, var_moment] = EPmomentsGaussQuad_fast(lf, y, mu, s2)
% constants for adaptive quadrature
persistent weight_point;
numW_P = 20;
nanwarn = 0;
infwarn = 0;
pinfwarn = 0;

if size(weight_point, 2) ~= numW_P
   weight_point = getP_W(numW_P);
end

numy = size(y,2);  % number of y per test point

% initialize storage
lZ = zeros(size(y));
if (nargout>1)
  mu_moment = zeros(size(y));
  if (nargout>2)
    var_moment = zeros(size(y));
  end
end

idexZ = find(s2<=0);
if ~isempty(idexZ)
   lZ(idexZ,:) =  logp_and_d(lf, y(idexZ,:), mu(idexZ));
   if (nargout>1)
      mu_moment(idexZ, :)  = mu;
      if (nargout>2)
	    var_moment(idexZ, :) = 0;
      end
   end 
end

idexN = find(s2>0);
if ~isempty(idexN)
    
for i = 1:numy
    %%% FASTER VERSION (but uses more memory) %%%
    Mstd   = sqrt(s2(idexN));
    Meta   = bsxfun(@plus, bsxfun(@times, weight_point(1, :), Mstd), mu(idexN));

    % get logp.  each row of Mlogp is for one {m,v}
    lpg = logp_and_d(lf, repmat(y(idexN, i), [1 numW_P]), Meta);
    
    % change NaNs to -inf (usually this is from: inf-inf)
    iinn = find(isnan(lpg));
    if ~isempty(iinn)
      lpg(iinn) = -inf;
      nanwarn = nanwarn + length(iinn);
    end
    % change +inf to -inf (more instabilities)
    % in general we should not have log(p) = inf
    iinn = find(isinf(lpg) .* (lpg>0));
    if ~isempty(iinn)
      lpg(iinn) = -inf;
      pinfwarn = pinfwarn+length(iinn);
    end
    
    fun_value = exp(lpg);
    
    % logp(eta) * Normal(eta|m,v)
    MlogpN = bsxfun(@times, fun_value, weight_point(2, :));
    lZ(idexN, i)  = log(sum(MlogpN,2));

    % check for lZ == -inf
    ii = find(isinf(lZ(idexN, i)));
    if ~isempty(ii)
      % lpg is too small, so try logtrick
      % tmp = logtrick(lpg(ii,:));
      tmp = logtrick(MlogpN(ii, :)')';
      lZ(idexN(ii), i) = tmp;% + log(eta_standard(2)-eta_standard(1));        % assumes equal spacing
      infwarn = infwarn + length(ii);

      % check correctness
      if 0
	t1 = log(trapz(eta,fun_value));
	t2 = tmp + log(eta(2)-eta(1));
	if sum(abs(t1-t2)./t2) > 1e-4
	  keyboard
	end
      end
    end
    
    if (any(isnan(lZ(i,:))))
      % NaN value means fun_value is too small or lpg is bad
      % or lp = inf-inf ~= -inf
      warning('NaN value in lpg or lZ');
      keyboard
      %ii = find(isnan(lZ));
      %lZ(ii) = -inf;
    end
    
    if (nargout>1)
      % moment computations cannot handle more than one y per test point
      % in general, this is not currently needed.
      if (numy ~= 1)
	error('cannot compute moments for more than 1 y!')
      end      
      
      % mean of q      
      lq = lpg - repmat(lZ(idexN, i), [1 numW_P]); % log q
      fun_value = Meta.*exp(lq);
      MlogpN = bsxfun(@times, fun_value, weight_point(2, :));
      mu_moment(idexN, i)  = sum(MlogpN,2);
      
      % variance of q
      if (nargout>2)
	   fun_value = (Meta-repmat(mu_moment(idexN, i), [1 numW_P])).^2 .* exp(lq);
       MlogpN = bsxfun(@times, fun_value, weight_point(2, :));
	   var_moment(idexN, i) = sum(MlogpN,2);
      end
    end
  end

end

if (nanwarn > 0)
  fprintf('warning EPmomentsNumInt: lpg: replaced %d NaNs with -infs\n', nanwarn);
end
if (pinfwarn > 0)
  fprintf('warning EPmomentsNumInt: lpg: replaced %d inf with -infs\n', ...
	  pinfwarn);
end
if (infwarn > 0)
  fprintf('warning EPmomentsNumInt: lZ: used log-trick %d times\n', infwarn);
end

if (nargout>1) && any(isnan(mu_moment)) 
  warning('NaN mu');
  keyboard
end
if (nargout>2) && any(isnan(var_moment)) 
  warning('NaN var');
  keyboard
end