function [varargout] = likExpo_generic(likFun, hyp, y, mu, s2, inf, i)
% likelihood function for generic expo family distribution
%
% [varargout] = likExpo_generic(lf, hyp, y, mu, s2, inf, i)
%
% in general, the function replicates the functionality of the
% GPML likelhood functions.  the function uses the parameter lf that
% contains the following information specific to each likelihood function:
%
% Note: lf.x(...) denotes a function handle
%
% === Exponential Family Parameters ==========================
%    lf.a()          -- a(phi) (note phi is constant)
%    lf.da()         -- derivative of a wrt hyp
%    lf.b(theta)     -- b(theta)
%    lf.db(theta)    -- derivative of b wrt theta
%    lf.d2b(theta)   -- 2nd derivative of b wrt theta
%    lf.d3b(theta)   -- 3rd derivative ...
%    lf.lh(y)        -- log h(y,phi)
%    lf.dlh(y)       -- derivative of lh wrt hyp
%    lf.theta(eta)   -- theta(eta)
%    lf.dtheta(eta)  -- derivative of theta wrt eta
%    lf.d2theta(eta) -- 2nd derivative of theta wrt eta
%    lf.d3theta(eta) -- 3rd derivative ...
%    lf.fix_phi      -- 1 = keep phi fixed by forcing dnlZ to 0
%                       0 = don't do that.
%
%    lf.b_and_d(theta) -- consolidated b function [optional]
%                           [b, db, d2b, d3b] = b_and_d(theta)
%         This is useful if b is difficult to compute. (e.g., see likExCOMPoisson)
%         If b_and_d exists, it will override the .b, .db, .d2b, .d3b
%         functions.
%
% === Special case: Expo Family b(theta, phi) ==================
%  For the special case where b() is a function of theta and hyp, 
%  an additional derivative is required to compute the derivative
%  wrt the hyperparameter. (e.g., see likExCOMPoisson)
%
%    lf.b_has_hyp      -- 1 = b is also a function of the hyperparameter
%                         0 = b only a function of theta [default]
%    lf.db_hyp(theta)  -- [db,dbp,dbpp] = lf.db_hyp(theta)
%                           db   = derivative of b wrt hyperparameter
%                           dbp  = derivative of b' wrt hyperparameter: 
%                                    d/dhyp d/dtheta b(theta, hyp)
%                           dbpp = derivative of b'' wrt hyperparameter
%                                    d/dhyp d^2/dtheta^2 b(theta, hyp)
%
% === Special case: transformed y =============================
%  some expo family models use a different sufficient statistic of
%  y, (e.g., see likExGammaScale1). 
%     lf.T(y)     -- sufficient statistic of y
%     lf.Tinv(x)  -- inverse sufficient statistic
%
% === Taylor Approximation Options ============================
%    lf.etahat(y)      -- expansion point for Taylor approximations
%      .etahat_has_hyp -- expansion point is a function of the hyperparameter
%      .detahat_hyp(y) -- derivative wrt hyperparameter
%
% === Expectation Propagation Options =========================
%  Moments and log marginals for EP:
%      log marginal : lZ = log int p(y|eta)G(eta,mu,s2)deta
%      moments of q : q(eta)=p(y|eta)G(eta,mu,s2)/Z
%                   : qmu    - mean
%                   : qvar   - variance
%                   : Eq_th  - E_q[theta(eta)]
%                   : Eq_bth - E_q[b(theta(eta))]
%  Specify a function handle for custom computation, OR
%  'numint' for numerical integration (default)
%  
%    lf.EP_moments(...)  -- [lZ, qmu, qvar] = EP_moments(y, mu, s2)
%    lf.EP_Eq(...)       -- [Eq_th, Eq_bth] = EP_Eq(y, mu, s2)
%
% === Prediction Options ======================================
%  Computing the predictive distribution: 
%    1) use custom function Pred_lp, if available.
%    2) use custom function EP_moments, if available.
%    3) use specified common method in EP_moments.
%    4) use numerical integration (default).
%
%    lf.Pred_lp(...)   -- log predictive likelihood: log p(y|X,x_*)
%                           [lp] = Pred_lp(y, mu, s2)
%                         y can be matrix (multiple y for each test point)
%                         mu & s2 are column vectors
%
%  Computing "mean" and "variance" of Y that is returned through gp.m:
%   1) use custom function Pred_Yout, if available.
%   2) use unscented transform to transform N(mu,s2) to Y-space,
%      using 3 control points [mu, mu-std, mu+std].
%      The mean is the mean of the 3 points.  The variance is the
%      the variance + observation noise variance (at mu)
%
%    lf.Pred_Yout(...) -- [ymu, ys2] = Pred_Yout(y, mu, s2)
%                         ymu - "mean" of predictive distribution
%                         ys2 - "variance" of predictive distribution
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27


% 2010-10-30: ABC -- created
%                 -- added support for infTaylor,infTaylor2,infEP,infLaplace
% 2010-10-31: ABC -- added support for custom moment functions (infEP)
% 2010-11-03: ABC -- added support for custom/default Y output
%                 -- added support for custom/default Y pred LL
%                 -- added support for multiple pred LL for each test point
% 2010-11-04: ABC -- added support for b(theta,phi), i.e. b is also a
%                    function of hyperparameter.
% 2010-11-05: ABC -- added log(y!) caching function
%                 -- consolidated logp/dlogp/d2logp/d3logp into the
%                    same function for speed.
%                 -- added lf.b_and_d for speed (COMPoisson only so far)
% 2010-11-07: ABC -- added support for lf.T(y) -- transform y
% 2010-11-23: ABC -- new testbench: test_deriv.m
% 2010-11-23: ABC -- fixed infTaylor derivative for b(theta,phi)
% 2010-11-25: ABC -- removed extra evaluation at mu for infTaylor
% 2010-12-02: ABC -- better ymu & ys2 prediction when using T(y).
% 2010-12-07: ABC -- fixed infLaplace implicit derivative wrt hyperparameter bug
%                 -- added support for infLaplace for b(theta,phi)
% 2010-12-13: ABC -- use log-trick for EP numerical integration, when sum=-inf
%                 -- added support for infEP for b(theta,phi) [testing]
% 2011-01-14: ABC -- put subfunctions into private directory.
% 2011-01-17: ABC -- put default predictive distribution using unscented into private/
% 2011-01-21: ABC -- added support for etahat(y, phi)
% 2011-08-16: ABC -- added support for lf.a() vectors (likExGaussYConf)
% 2013-11-27: ABC -- changes for GPML v3.4
%                     - change output: sum(lp) -> lp
%                     - change output for new version of infLaplace
%                  - combined comPoisson_internal for COMPoisson/COMPoissonLinear
%
% TODO - add support for GPMLv3.4 KL minimization
%      - update likelihood function to:
%              likExpo_generic(lik, theta, ...)
% TODO
%     x - infEP for T(y) 
%     x - EPmomentsNumInt -- what to do when everythnng is -inf?
%      - EPmomentsQuad -- numerical integration using "quad" or "quadv"
%          [may not be faster...needs log-trick version of quad]
%      - singular matrix warnings in infTaylor
%      - canonical link flag
%      - conjugate prior moments/pred
%      - speed ups/optimization!
%        - convert likEx* to use consolidated b_and_d
%        - consolidate theta/dtheta/d2theta functions into own
%          structure and function (easier to define and
%          maintain). see theta_*.m
%        - use cache for Z in COMPoisson
%      - we may not support more than 1 likelihood hyperparameter! (check i)

if nargin < 2
   varargout = {num2str(feval(likFun))};
   return;
end

lf = feval(likFun, hyp);

if nargin<5+1         %prediction mode
  
  if numel(y)==0,  y = ones(size(mu)); end                   % make y a vector
  s2zero = 1; if nargin>3+1, if norm(s2)>0, s2zero = 0; end, end         % s2==0 ?
  if s2zero                                         % log probability evaluation
    lp = logp_and_d(lf, y, mu);
  else                                                              % prediction

    % use custom Pred_lp
    if (isfield(lf, 'Pred_lp') && isa(lf.Pred_lp, 'function_handle'))
      lp = lf.Pred_lp(y, mu, s2);

    % use custom EP_moments (slow but requires no extra work)
    elseif (isfield(lf, 'EP_moments') && isa(lf.EP_moments, 'function_handle'))
      lp = zeros(size(y));
      % do each column one at a time
      for i=1:size(y,2)
        lp(:,i) = lf.EP_moments(y(:,i), mu, s2);
      end
    else
      
      % use generic EP_moments
      if (isfield(lf, 'EP_moments'))
        myPmethod = getEPmethod(lf.EP_moments);
      else
        % use default
        myPmethod = @EPmomentsNumInt;
        % myPmethod = @EPmomentsLaplace;
      end
      lp = myPmethod(lf, y, mu, s2);
      
      %likExpo_generic(lf, hyp, y, mu, s2, 'infEP');  % the old way
    end
  end
  
  ymu = {}; ys2 = {};

  % use a custom function for predictive Y output
  if (isfield(lf, 'Pred_Yout') && isa(lf.pred_Yout, 'function_handle'))
    if (nargout>2)
      [ymu, ys2] = Pred_Yout(y, mu, s2);
    else
      [ymu] = Pred_Yout(y, mu, s2);
    end
  else
    
    % use defaults: unscented transform
    if (nargout>2)
      % [ymu, ys2] = pred_dist_unscented(lf, y, mu, s2);
      [ymu, ys2] = pred_dist_NumInt(lf, y, mu, s2);                       
    else
      % [ymu] = pred_dist_unscented(lf, y, mu, s2);
      [ymu] = pred_dist_NumInt(lf, y, mu, s2);
    end
    
  end
  
  varargout = {lp,ymu,ys2};
  
else
    
  switch inf
    
    %%% LAPLACE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
   case 'infLaplace'           % laplace inference, requires
    if nargin<6+1                                             % no derivative mode
      if numel(y)==0, y=0; end
      dlp = {}; d2lp = {}; d3lp = {};
      
      if 0
        % OLD METHOD USING SINGLE CALLS
        lp = logp(lf, y, mu);	
        if nargout>1
          % dlp, derivative of log likelihood w.r.t mu
          dlp = dlogp(lf, y, mu);	  
          if nargout>2
            % d2lp, 2nd derivative of log likelihood
            d2lp = d2logp(lf, y, mu);	    
            if nargout>3
              % d3lp, 3rd derivative of log likelihood
              d3lp = d3logp(lf, y, mu);
            end
          end
        end
      end
      
      if nargout>3
        [lp, lpv, dlp, d2lp, d3lp] = logp_and_d(lf, y, mu);
      elseif nargout>2
        [lp, lpv, dlp, d2lp] = logp_and_d(lf, y, mu);
      elseif nargout>1
        [lp, lpv, dlp] = logp_and_d(lf, y, mu);
      else
        [lp] = logp_and_d(lf, y, mu);
      end
      
      varargout = {lp,dlp,d2lp,d3lp};
    else                                                       % derivative mode
      if (lf.fix_phi)
        varargout = {zeros(size(y)),zeros(size(y)),zeros(size(y))};
      else
        % derivatives of log likelihood w.r.t. hypers
        [lp_dhyp, d2lp_dhyp, dlp_dhyp] = dlogp_dhyp(lf, y, mu);
        
        varargout = {lp_dhyp, dlp_dhyp, d2lp_dhyp};
        
        % old version (before GPML v3.4)
        %varargout = {lp_dhyp, d2lp_dhyp, dt_dwu};
      end
    end
    
    
    %%% EP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   case 'infEP'            
    if nargin<6+1 % no derivative mode
      dlZ = {}; d2lZ = {};
      
      % set default
      if (~isfield(lf, 'EP_moments'))
        lf.EP_moments = 'numint';
      end
      
      % use custom function!
      if isa(lf.EP_moments, 'function_handle')	
        if (nargout>2)
          [lZ, mu_moment, var_moment] = lf.EP_moments(y, mu, s2);
        elseif (nargout>1)
          [lZ, mu_moment] = lf.EP_moments(y, mu, s2);
        else
          [lZ] = lf.EP_moments(y, mu, s2);
        end    
      else
        % get generic method
        myEPmoment = getEPmethod(lf.EP_moments);
        
        % use the generic method
        if (nargout>2)
          [lZ, mu_moment, var_moment] = feval(myEPmoment, lf, y, mu, s2);
          if (var_moment<=0)
            a = 1;
          end
        elseif (nargout>1)
          [lZ, mu_moment] = feval(myEPmoment, lf, y, mu, s2);
        else
          [lZ] = feval(myEPmoment, lf, y, mu, s2);
        end    	 
      end
      
      if (nargout>1)
        dlZ = (mu_moment - mu) ./ s2;	
        if (nargout>2)
          d2lZ = var_moment ./ (s2.*s2) - 1./s2;
        end
      end

      % check variance moment
      if (nargout>2)
        if (var_moment<=0)
          warning('bad var moment');
          keyboard
        end
      end
            
      varargout = {lZ,dlZ,d2lZ};
      
    else                                                % derivative mode
      if (lf.fix_phi)
        varargout = {zeros(size(y))};
      else 
        % derivative mode
        
        % set default
        if (~isfield(lf, 'EP_Eq'))
          lf.EP_Eq = 'numint';
        end
	
        % use custom function!
        if isa(lf.EP_Eq, 'function_handle')
          [EVth, EVbth] = lf.EP_Eq(y, mu, s2);
        else
          % use generic methods
          switch(lf.EP_Eq)
            case 'numint'
              if isfield(lf, 'b_has_hyp') && lf.b_has_hyp
                % get extra EV(dbhyp)
                [EVth, EVbth, EVdbhyp] = EPderivNumInt(lf, y, mu, s2);
                % [EVth, EVbth, EVdbhyp] = EPderivGaussQuad(lf, y, mu, s2);
              else
                % default
                [EVth, EVbth] = EPderivNumInt(lf, y, mu, s2);
              end
            otherwise
              error('bad EP_Eq');
          end
        end
        
        
        % transform y
        if isfield(lf, 'T')
          Ty = lf.T(y);
        else
          Ty = y;
        end
        
        dlZhyp = lf.dlh(y) - (lf.da()./(lf.a().^2))*(Ty.*EVth - EVbth);	
        
        % add derivative of b wrt hyperparameter
        if isfield(lf, 'b_has_hyp') && lf.b_has_hyp
          dlZhyp = dlZhyp - EVdbhyp./lf.a();
        end
        
        varargout = {dlZhyp};
      end                                   
    end
                
    %%% TAYLOR APPROXIMATIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   case {'infTaylor','infTaylor2'}
    if nargin<6+1
      if numel(y)==0, y=0; end
      
      switch inf
       case 'infTaylor'
         % these terms not used by infTaylor
         lp = []; lpv = []; dlp = [];
        case 'infTaylor2'
          % evaluation at mu
          [lp,lpv,dlp] = logp_and_d(lf, y, mu);
      end
      
      % evaluation at expansion point
      etahat = lf.etahat(y);
      %[xlp, xlpv] = logp(lf, y, etahat);
      %xdlp        = dlogp(lf, y, etahat);
      %xd2lp       = d2logp(lf, y, etahat);
      [xlp,xlpv,xdlp,xd2lp] = logp_and_d(lf, y, etahat);
      
      u = xdlp;
      w = -1./xd2lp;
      
      % check w is negative --
      %   This happens when the expansion point is not close to the
      %   mode of p.  e.g., after the inflection point of the logp
      if any(w < 0) 
        warning('w is negative');
                
        % force truncation
        w = max(w,1e-4);
      end
      
      t = etahat + w.*u;
      r = xlp + 0.5*u.*u.*w + 0.5*log(w);
      v = xlpv;
            
      % old-style output
      %varargout = {lp,lpv,dlp,u,w,v,t,r};
      
      % new-style output  
      Xout.lp  = lp;    Xout.lpv = lpv;    Xout.dlp = dlp;  % NOTE: this row only used by infTaylor2
      Xout.u   = u;     Xout.w   = w;      Xout.v   = v;
      Xout.t   = t;     Xout.r   = r;
      varargout = {Xout,nan,nan,nan,nan,nan,nan,nan};
      
    else                                 % derivative wrt hyplik
      if (lf.fix_phi)
        % old-style output
        %varargout = {zeros(size(y)),lf.a(),zeros(size(y)),0};
	
        % new-style output
        XXout.lh      = zeros(size(y));
        XXout.ahyp    = lf.a();
        XXout.dlh_hyp = zeros(size(y));
        XXout.da_hyp  = 0;
        varargout = {XXout,nan,nan,nan};
        
      else
        lh      = lf.lh(y);
        ahyp    = lf.a();
        dlh_hyp = lf.dlh(y);
        da_hyp  = lf.da();
        
        % add derivative of b wrt hyperparameter
        if isfield(lf, 'b_has_hyp') && lf.b_has_hyp
          if strcmp(inf, 'infTaylor')
            etahat = lf.etahat(y);
            th     = lf.theta(lf.etahat(y));
            [XXout.db_hyp, XXout.dbp_hyp, XXout.dbpp_hyp] = lf.db_hyp(th);
            XXout.dtheta   = lf.dtheta(etahat);
            XXout.d2theta  = lf.d2theta(etahat);
            
          else  
            error('infTaylor2 not handled yet');
          end
        end
        
        % add derivatives of etahat wrt hyperparameter
        if (isfield(lf, 'etahat_has_hyp') && lf.etahat_has_hyp)
          if strcmp(inf, 'infTaylor')
            XXout.detahat_hyp = lf.detahat_hyp(y);
            etahat = lf.etahat(y);
            [tmp_lp, tmp_lpv, tmp_dlp, tmp_d2lp, tmp_d3lp] = logp_and_d(lf, y, etahat);
            
            % things to pass to infTaylor
            XXout.d3lp = tmp_d3lp;
                    
          else
            error('infTaylor2 not handled yet');
          end	    
        end
	
        % old-style output
        %varargout = {lh,ahyp,dlh_hyp,da_hyp};
        
        % new-style output
        XXout.lh      = lh;
        XXout.ahyp    = ahyp;
        XXout.dlh_hyp = dlh_hyp;
        XXout.da_hyp  = da_hyp;
        varargout = {XXout,nan,nan,nan};
      end
    end
    
    
    % case 'infVB'                % variational bayes (not supported)
	
   case 'XXXinfKLMin' % old KL minimization (not supported)
    if nargin<6+1
      if numel(y)==0, y=0; end
      [dm,d2m,dv,d2v,dmv,el] = KLderivCompute(lf,mu,s2,y);  % el is the expectation of logp                
      varargout = {el,dm,dv,d2m,d2v,dmv};
      
    else                                 % derivative wrt hyplik
      if (lf.fix_phi)
        varargout = {zeros(size(y)),lf.a(),zeros(size(y)),0};
      else
        lh      = lf.lh(y);
        ahyp    = lf.a();
        dlh_hyp = lf.dlh(y);
        da_hyp  = lf.da();
        exp_term = lf.etheta(mu,s2).*y - lf.eb(mu,s2);
        
        % add derivative of b wrt hyperparameter
        if isfield(lf, 'b_has_hyp') && lf.b_has_hyp
          error('b_has_hyp not implemented');
        end
        
        varargout = {lh,ahyp,dlh_hyp,da_hyp,exp_term};
      end
    end
    
       % the new KL divergence (not supported)
   case 'XXXinfKLD'
    if nargin<6+1
      % posterior      
      if numel(y)==0, y=0; end
            
      % set default
      if (~isfield(lf, 'KLD_E'))
        lf.KLD_E = 'numint';
      end
      
      % use custom function!
      if isa(lf.KLD_E, 'function_handle')
        out = KLDderiv_expectations(lf, mu, s2, y);
               
      else
        % use the generic method
%         [out] = KLDderiv_numint(lf, mu, s2, y); 
        [out] = KLDderiv_GaussQuad(lf, mu, s2, y);
      end      

      varargout = {out};
      
    else
      % hyps
      varargout = {[]};
    end
    
  end
end

return












