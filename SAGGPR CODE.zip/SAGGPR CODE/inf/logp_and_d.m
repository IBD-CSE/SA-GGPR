%%% log-likelihood + derivatives %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consolidated function that computes:
%   1) log-likelihood 
%   2) derivative of log-likelihood wrt eta
%   3) 2nd derivative of log-likelihood wrt eta
%   4) 3rd derivative of log-likelihood wrt eta
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

function [lp, lpv, dlp, d2lp, d3lp] = logp_and_d(lf, y, eta)
% up to the caller to make sure eta and y match in size
te = lf.theta(eta);

% group calculate b and derivatives
if isfield(lf, 'b_and_d')
  if nargout>4
    [bte, dbte, d2bte, d3bte] = lf.b_and_d(te);
  elseif nargout>3
    [bte, dbte, d2bte] = lf.b_and_d(te);
  elseif nargout>2
    [bte, dbte] = lf.b_and_d(te);
  else
    [bte] = lf.b_and_d(te);
  end
else
  % otherwise, call single functions
  bte = lf.b(te);
  if nargout>2
    dbte = lf.db(te);
    if nargout>3
      d2bte = lf.d2b(te);
      if nargout>4
	d3bte = lf.d3b(te);
      end
    end
  end
end

% transform y
if isfield(lf, 'T')
  Ty = lf.T(y);
else
  Ty = y;
end

% logp
lpv = (Ty.*te - bte)./lf.a();
lp  = lpv + lf.lh(y);

if (nargout>2)
  % dlogp
  dte  = lf.dtheta(eta);    % theta'(eta)
  ygi  = Ty - dbte;
  dlp  = dte.*(ygi) ./ lf.a();

  if (nargout>3)
    % d2logp
    d2te  = lf.d2theta(eta);   % theta''(eta)
    dgi   = d2bte.*dte;   % [g^-1]'
    d2lp  = ( (ygi).*d2te - dgi.*dte ) ./ lf.a();
    
    if (nargout>4)
      % d3logp
      d3te = lf.d3theta(eta);   % theta'''(eta)
      d2gi = d3bte.*(dte.^2) + d2bte.*d2te;
      d3lp = -(dte.*d2gi + 2*d2te.*dgi - d3te.*(ygi)) ./ lf.a();
    end
  end
end

% check output
if 0
  things2check = {'te', 'dte', 'd2te', 'd3te', ...
		  'bte', 'dbte', 'd2bte', 'd3bte', ...
		  'lp', 'dlp', 'd2lp', 'd3lp'};
  for ii=1:length(things2check)
    myvar = things2check{ii};
    if exist(myvar)
      if any(isnan(eval(myvar)))
	warning(sprintf('%s is NaN', myvar))
	keyboard
      end
    end
  end

end


if 0
  % check with old
  [olp, olpv] = logp(lf, y, eta);
  olderr(1) = sum(abs(olp(:)-lp(:)));
  olderr(2) = sum(abs(olpv(:)-lpv(:)));
  if nargout>2
    olderr(3) = sum(abs(dlp(:) - dlogp(lf, y, eta)));
    if nargout>3
      olderr(4) = sum(abs(d2lp(:) - d2logp(lf, y, eta)));
      if nargout>4
	olderr(5) = sum(abs(d3lp(:) - d3logp(lf, y, eta)));
      end
    end
  end
  if any(olderr > 1e-6)
    warning('error high?');
    keyboard
  end
end



if 0
  % OLD FUNCTIONS
  %%% log-likelihood %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %function [lp, lpv] = logp(lf, y, eta)
  % up to the caller to make sure eta and y match in size
  te = lf.theta(eta);
  lpv = (y.*te - lf.b(te))/lf.a();
  lp  = lpv + lf.lh(y);
  
  %%% derivative of log-likelihood wrt eta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %function [dlp] = dlogp(lf, y, eta)
  te  = lf.theta(eta);
  dlp = lf.dtheta(eta).*(y - lf.db(te)) / lf.a();
  
  
  %%% 2nd derivative of log-likelihood wrt eta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %function [d2lp] = d2logp(lf, y, eta)
  te   = lf.theta(eta);
  d2lp = ( (y-lf.db(te)).*lf.d2theta(eta) ...
	   - lf.d2b(te).*(lf.dtheta(eta).^2) ) / lf.a();
  
  
  %%% 3rd derivative of log-likelihood wrt eta %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %function [d3lp] = d3logp(lf, y, eta)
  te   = lf.theta(eta);     % theta(eta)
  dte  = lf.dtheta(eta);    % theta'(eta)
  d2te = lf.d2theta(eta);   % theta''(eta)
  d3te = lf.d3theta(eta);   % theta'''(eta)
  gi   = lf.db(te);         % g^-1 = b'(theta(eta))
  dgi  = lf.d2b(te).*dte;   % [g^-1]'
  d2gi = lf.d3b(te).*(dte.^2) + lf.d2b(te).*d2te;
  
  d3lp = -(dte.*d2gi + 2*d2te.*dgi - d3te.*(y-gi))/lf.a();
end
