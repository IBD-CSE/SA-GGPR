function [post nlZ dnlZ] = infTaylor(hyp, mean, cov, lik, x, y)
% Taylor approximation to the GP.
%
% The function uses the same input arguments as other GPML inference functions, 
% and also returns the same information as infLaplace.
%
% The likelihood function needs to be modified to output the appropriate
% derivatives for 'infTaylor'.  See likExpo_generic for an example.
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

% INPUT ARGUMENTS
%   hyp      is a struct of hyperparameters
%   cov      is the name of the covariance function (see covFunctions.m)
%   lik      is the name of the likelihood function (see likFunctions.m)
%   x        is a n by D matrix of training inputs 
%   y        is a (column) vector (of size n) of targets
%
%   nlZ      is the returned value of the negative log marginal likelihood
%   dnlZ     is a (column) vector of partial derivatives of the negative
%               log marginal likelihood w.r.t. each hyperparameter
%   post     struct representation of the (approximate) posterior containing 
%     alpha  is a (sparse or full column vector) containing inv(K)*m, where K
%               is the prior covariance matrix and m the approx posterior mean
%     sW     is a (sparse or full column) vector containing diagonal of sqrt(W)
%               the approximate posterior covariance matrix is inv(inv(K)+inv(W))
%     L      is a (sparse or full) matrix, L = chol(sW*K*sW+eye(n))

% Daxiang Dong sep 18 2010

% 2010-10-29: BUG fix - derivative of MLL
% 2010-10-30: call likelihood with output:  [lp,lpv,dlp,u,w,v,t,r]
% 2010-11-23: changed output of likfunc to be a struct (easier to adapt)
%           : add support for derivative of hyperparameter when b(theta,phi)
% 2010-11-25: removed extra lp,lpv,dlp variables (unused)
% 2011-01-21: add support for etahat(y,phi)
%           : only compute inv(K+W) once
% 2011-08-16: add support for lf.a() vectors
% 2013-11-27: Updated to GPML 3.4
%               - fixed cov call for kernel derivatives

% if ~ischar(lik), lik = func2str(lik); end    % make likelihood variable a string
% removed by lifeng
inf = 'infTaylor';
n = size(x,1);

K = feval(cov{:},  hyp.cov,  x);                % evaluate the covariance matrix
m = feval(mean{:}, hyp.mean, x);                      % evaluate the mean vector

f = m;

% note that f doesn't matter, since the derivatives are computed at
% the expansion point (ignoring f and std)
[X1,X2,X3,X4,X5,X6,X7,X8] = feval(lik{:},hyp.lik,y,f,[],inf);

if isstruct(X1)
  % use structure output in X1
%  lp  = X1.lp;  lpv = X1.lpv;  dlp = X1.dlp;  % NOT USED!
  u   = X1.u;   w   = X1.w;    v   = X1.v;
  t   = X1.t;   r   = X1.r;
else
  % use individual outputs (backwards compatability)
%  lp  = X1;  lpv = X2;  dlp = X3;  % NOT USED!
  u   = X4;  w   = X5;  v   = X6;
  t   = X7;  r   = X8;
  warning('infTaylor using old-style likfunc call');
end

isWneg = any(w<0);       % flag indicating whether we found negative values of W
if isWneg
  w = max(w,0);
end

sW = 1./sqrt(w);      

% L'*L=B=eye(n)+sW*K*sW    
[L, foo] = chol(eye(n)+sW*sW'.*K);
if (foo > 0)
%   warning('chol error');
%   keyboard
end

%   [ldA, iA, post.L] = logdetA(K,w); 
alpha = (K+diag(w))\(t-m);
post.alpha = alpha;
post.sW = sW;
post.L = L;

%   % compute det 
%   [ldA,iA,mwiA] = logdetA(K,1./w);

% the negative log marginal
if nargout>1                                % do we want the marginal likelihood  
  % nlZ = ((t-m)'*alpha)/2 + log(det(K+diag(w)+eye(n)))/2 - sum(r,1);
  % Note: log(det(K+diag(w))) = log(det(L'*L)det(W))
  
  %nlZ = ((t-m)'*alpha)/2 + trace(log(L)) - sum(r,1);
  nlZ = ((t-m)'*alpha)/2 + sum(log(diag(L))) - sum(log(sW)) - sum(r,1);
  
  % check:
  %foo = -0.5*t'*inv(K+diag(w))*t - 0.5*log(det(K+diag(w))) + sum(r);
  
  % cache inv(K+W)  -- eventually we should switch to not using inv
  invKW = inv(K+diag(w));
  
  if nargout>2            % derivative of the marginal likelihood
    dnlZ = hyp;         % allocate space for the derivative
        
    for j=1:length(hyp.cov)
      dK = feval(cov{:}, hyp.cov, x, [], j);
      %dnlZ.cov(j) = trace((inv(K+diag(w))-alpha*alpha')*dK);
	  dnlZ.cov(j) = 0.5*trace((invKW-alpha*alpha')*dK);   
    end
    
	for j=1:length(hyp.lik)     
      [X1,X2,X3,X4] = feval(lik{:},hyp.lik,y,f,[],inf,j);
      if isstruct(X1)  % use structure output
        lh      = X1.lh;	ahyp    = X1.ahyp;
        dlh_hyp = X1.dlh_hyp;	da_hyp  = X1.da_hyp;
        if isfield(X1, 'db_hyp')
          % get things when b(theta, phi)
          do_bphi = 1;
          db_hyp   = X1.db_hyp;
          dbp_hyp  = X1.dbp_hyp;
          dbpp_hyp = X1.dbpp_hyp;
          dtheta   = X1.dtheta;
          d2theta  = X1.d2theta;
        else
          do_bphi = 0;
        end	
        
        if isfield(X1, 'detahat_hyp')
          % get things when etaahat(theta, phi)
          do_etahatphi = 1;
          detahat_hyp = X1.detahat_hyp;
          d3lp        = X1.d3lp;
        else
          do_etahatphi = 0;
        end
	
      else % use individual output (backwards compatibility)
        lh      = X1;	ahyp    = X2;
        dlh_hyp = X3;	da_hyp  = X4;
        do_bphi = 0;
        warning('infTaylor using old-style likfunc call for derivatives');
      end
           
      %% NEW METHOD (compute intermediate things)
      dw    = (da_hyp./ahyp) .* w;
      du    = -(da_hyp./ahyp) .* u;
      dt    = 0;
      %dlogp = -(da_hyp./ahyp)*sum(v,1) + sum(dlh_hyp,1);
      dlogp = -sum(da_hyp./ahyp.*v , 1) + sum(dlh_hyp,1);
      
      if (do_bphi)
        % add extra terms to derivatives when b(theta,phi)
        dw    = dw - (w.^2).*(dbpp_hyp.*dtheta.^2 + dbp_hyp.*d2theta) ./ ahyp;
        du    = du - dtheta.*dbp_hyp ./ ahyp;
        dt    = w.*du + u.*dw;
        dlogp = dlogp - sum(db_hyp,1)./ahyp;
      end
      
      % kernel term
      tmp_k = alpha'*diag(dw)*alpha/2 - trace(invKW*diag(dw))/2;

      if (do_bphi)
        % extra term when b(theta,phi)
        tmp_k = tmp_k - alpha'*dt;
      end
      
      % r term
      tmp_r = dlogp + 0.5*(u.*u)'*dw + (u.*du)'*w + 0.5*sum(dw./w);
      
      tmp = tmp_r + tmp_k;
      
      % if etahat(y, phi), add implicit derivative
      if (do_etahatphi)
	
        dw_deta = (w.*w).*d3lp;
        %du_deta = -1./w;
        dt_deta = u.*dw_deta;
        
        dqdeta_1 = -((invKW*dt_deta).*t) + 0.5*(dw_deta.*(invKW*t).^2);
        dqdeta_2 = -0.5*(diag(invKW).*dw_deta);
        dqdeta_3 = 0.5*(u.*u + 1./w).*dw_deta;
        
        dqdeta = dqdeta_1 + dqdeta_2 + dqdeta_3;
        
        tmp_e = detahat_hyp' * dqdeta;
        tmp = tmp + tmp_e;
                
      end      
      
      % derivative of *negative* log MLL
      dnlZ.lik(j) = -tmp;
            
      %dnlZ.lik(j) = ahyp/da_hyp*(sum(v)-(z-u)'*inv(diag(1./w)+inv(K))*z+trace(inv(K+W)*K)/2) + sum(dlh_hyp,1);
    end
    
    for j=1:length(hyp.mean)                                         % mean hypers
      dnlZ.mean(j) = -feval(mean{:}, hyp.mean, x, j)'*alpha;
    end
  end
end


end % end function



% Compute the log determinant ldA and the inverse iA of a square nxn matrix 
% A = eye(n) + K*diag(w) from its LU decomposition; for negative definite A, we 
% return ldA = Inf. We also return mwiA = -diag(w)*inv(A).
function [ldA,iA,mwiA] = logdetA(K,w)
[m,n] = size(K); if m~=n, error('K has to be nxn'), end
A = eye(n)+K.*repmat(w',n,1);
[L,U,P] = lu(A); u = diag(U);           % compute LU decomposition, A = P'*L*U
signU = prod(sign(u));                                             % sign of U
detP = 1;                 % compute sign (and det) of the premutation matrix P
p = P*(1:n)';
for i=1:n
  if i~=p(i)
    detP = -detP; j = find(p==i); p([i,j]) = p([j,i]); % swap entries
  end
end
if signU~=detP  % log becomes complex for negative values, encoded by infinity
  ldA = Inf;
else            % det(L) = 1 and U triangular => det(A) = det(P)*prod(diag(U))
  ldA = sum(log(abs(u)));
end 
if nargout>1, iA = inv(U)*inv(L)*P; end          % return the inverse, as well
if nargout>2, mwiA = -repmat(w,1,n).*iA; end
end

 
