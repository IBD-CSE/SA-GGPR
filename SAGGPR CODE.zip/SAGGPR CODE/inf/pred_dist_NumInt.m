function [ymu, ys2] = pred_dist_NumInt(lf, y, mu, s2);
% pred_dist_unscented -- predictive distribution statistics using unscented transform
%
% Computes the mean and variance of the predictive distribution
% using the unscented transform.
%
%  not really correct, but the best we can do without computing the preditive distribution
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27


ymu = zeros(size(mu));
ys2 = zeros(size(mu));

%ymu = lf.db(lf.theta(mu));

% predicted Y mean is the mean of f(x) projected into Y space
% (using unscented transform)
%
% i.e.
%  p(y) = \int p(y|eta) p(eta) deta
%  E[y] = \int \int y p(y|eta) p(eta) deta dy
%      \approx  (1/3) \sum_s \int y p(y|eta_s) dy
%             = (1/3) \sum_s E(y|eta_s)
%      
%     where eta_s are the control points (mean +- std)
%
%tmps = sqrt(s2)*sqrt(3)/2;  % actual unscented

% constants for numerical integration
INTSIZE = 2000;
INTSTD  = 3;

for i = 1 : length(mu)
    % use std points to make it consistent for gaussians
    eta = linspace(mu(i)-INTSTD*sqrt(s2(i)), mu(i)+INTSTD*sqrt(s2(i)), INTSIZE)';
    % compute E(y|eta_s)
    pfun = @(eta) 1/sqrt(2*pi*s2(i)) * exp(-(eta - mu(i)).^2/(2 * s2(i)));
    pfun_value = pfun(eta);
    Ey_etas = lf.db(lf.theta(eta));
    vary_etas = lf.a()*lf.d2b(lf.theta(eta));
    
    if isfield(lf, 'T')
    % special case: using T(y)
    % Ey_etas = lf.Tinv(Ey_etas);
    % ymu = mean(Ey_etas,2);
  
    % what we computed was actually E[T(y)|etas] and var[T(y)|etas]
    ETy_etas   = Ey_etas;
    varTy_etas = vary_etas;
  
    % unscented approximation:  T(y)|etas ~ N(E[y|etas] | var(y|etas))
    %    --> E[y|etas] = E(Tinv(T(y))|etas) \approx mean( Tinv(Teta_s) )
    %    --> var(y|etas) = var(Tinv(T(y))|etas) \approx var(Tinv(Teta_s))
    % where Tetas_s are control points from N(E[y|etas] | var(y|etas))
    for ii = 1 : INTSIZE
      tmp = sqrt(varTy_etas(ii));
      Tetas = [ETy_etas(ii), ETy_etas(ii)-tmp, ETy_etas(ii)+tmp];
      Ey_etas(ii)   = mean(lf.Tinv(Tetas), 2);
      vary_etas(ii) = var(lf.Tinv(Tetas), 0, 2);
    % use unbiased variance to match when Ty=y
    end
   end
    
    fun_value = Ey_etas .* pfun_value;
    ymu(i) = trapz(eta, fun_value);
    
    if nargout>1
      % compute var(y|eta_s)
      fun_value = (Ey_etas.^2 + vary_etas + ymu(i)^2 - 2*ymu(i)*Ey_etas) .* pfun_value;
      ys2(i) = trapz(eta, fun_value);
    end
end
return

% % % % % for i = 1 : length(mu)
% % % % %     % use std points to make it consistent for gaussians
% % % % %     eta = linspace(mu(i)-INTSTD*sqrt(s2(i)), mu(i)+INTSTD*sqrt(s2(i)), INTSIZE)';
% % % % %     % compute E(y|eta_s)
% % % % %     pfun = @(eta) 1/sqrt(2*pi*s2(i)) * exp(-(eta - mu(i)).^2/(2 * s2(i)));
% % % % %     pfun_value = pfun(eta);
% % % % %     Ey_etas = lf.db(lf.theta(eta));
% % % % %     vary_etas = lf.a()*lf.d2b(lf.theta(eta));
% % % % %     
% % % % %     if isfield(lf, 'T')
% % % % %     % special case: using T(y)
% % % % %     % Ey_etas = lf.Tinv(Ey_etas);
% % % % %     % ymu = mean(Ey_etas,2);
% % % % %   
% % % % %     % what we computed was actually E[T(y)|etas] and var[T(y)|etas]
% % % % %     ETy_etas   = Ey_etas;
% % % % %     varTy_etas = vary_etas;
% % % % %   
% % % % %     % unscented approximation:  T(y)|etas ~ N(E[y|etas] | var(y|etas))
% % % % %     %    --> E[y|etas] = E(Tinv(T(y))|etas) \approx mean( Tinv(Teta_s) )
% % % % %     %    --> var(y|etas) = var(Tinv(T(y))|etas) \approx var(Tinv(Teta_s))
% % % % %     % where Tetas_s are control points from N(E[y|etas] | var(y|etas))
% % % % %     for ii = 1 : INTSIZE
% % % % %       tmp = sqrt(varTy_etas(ii));
% % % % %       Tetas = [ETy_etas(ii), ETy_etas(ii)-tmp, ETy_etas(ii)+tmp];
% % % % %       Ey_etas(ii)   = mean(lf.Tinv(Tetas), 2);
% % % % %       vary_etas(ii) = var(lf.Tinv(Tetas), 0, 2);
% % % % %     % use unbiased variance to match when Ty=y
% % % % %     end
% % % % %    end
% % % % %     
% % % % %     fun_value = Ey_etas .* pfun_value;
% % % % %     ymu(i) = trapz(eta, fun_value);
% % % % %     
% % % % %     if nargout>1
% % % % %       % compute var(y|eta_s)
% % % % %       fun_value = (Ey_etas.^2 + vary_etas + ymu(i)^2 - 2*ymu(i)*Ey_etas) .* pfun_value;
% % % % %       ys2(i) = trapz(eta, fun_value);
% % % % %     end
% % % % % end
% % % % % return
