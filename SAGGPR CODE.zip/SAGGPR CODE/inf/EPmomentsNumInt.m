%%% compute EP moments using numerical integration %%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Moments and log marginals for EP:
%      log marginal : lZ = log int p(y|eta)G(eta,mu,s2)deta
%      moments of q : q(eta)=p(y|eta)G(eta,mu,s2)/Z
%
% Also used to compute predictive log-likelihoods (y can be a matrix)
%
% lf -- expo family structure
% y  -- [N x ?]  - data points [N x 1], or target predictions [N x ny]
% mu -- [N x 1]  - posterior means
% s2 -- [N x 1]  - posterior variances
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

% 2013-12-13 -- fixed bug when re-calculating values when lZ=-inf

function [lZ, mu_moment, var_moment] = EPmomentsNumInt(lf, y, mu, s2)

%tic

% constants for numerical integration
NUMPOINTS = 1200;

% generate a standard Gaussian N(0,1) between -5 and 5 sigmas
persistent eta_standard N_standard delta_standard logN_standard

%eta_standard = [];
if isempty(eta_standard)
  eta_standard = linspace(-5,5,NUMPOINTS);
  N_standard   = normpdf(eta_standard,0,1);
  delta_standard = eta_standard(2)-eta_standard(1);
  logN_standard = log(N_standard);
end

numy = size(y,2);  % number of y per test point
numt = size(y,1);  % number of test points

% initialize storage
lZ = zeros(size(y));
if (nargout>1)
  mu_moment = zeros(size(y));
  if (nargout>2)
    var_moment = zeros(size(y));
  end
end

nanwarn = 0;
infwarn = 0;
pinfwarn = 0;

idexZ = find(s2<=0);
if ~isempty(idexZ)
   lZ(idexZ,:) =  logp_and_d(lf, y(idexZ,:), mu(idexZ));
   if (nargout>1)
      mu_moment(idexZ, :)  = mu;
      if (nargout>2)
	    var_moment(idexZ, :) = 0;
      end
   end 
end

idexN = find(s2>0);
if ~isempty(idexN)
    
for i = 1:numy
    %%% FASTER VERSION (but uses more memory) %%%
    Mstd   = sqrt(s2(idexN));
    Meta   = bsxfun(@plus, bsxfun(@times, eta_standard, Mstd), mu(idexN));
    Mdelta = delta_standard*Mstd;

    % get logp.  each row of Mlogp is for one {m,v}
    lpg = logp_and_d(lf, repmat(y(idexN, i), [1 NUMPOINTS]), Meta);
    % lg = -0.5*(Meta-repmat(mu(:), [1 NUMPOINTS])).^2./repmat(s2(:), [1 NUMPOINTS])...
    %     - 0.5*log(2*pi) - 0.5*log(repmat(s2(:), [1 NUMPOINTS]));
    % lpg = lpg + lg;
    % log data likelihood + log gaussian likelihood    
    %lpg = logp_and_d(lf, repmat(y(i,:),[INTSIZE 1]), repmat(eta,1,numy)) + ...
%	  repmat(-0.5*(eta-mu(i)).^2/s2(i) - 0.5*log(2*pi) - 0.5*log(s2(i)), [1
%	  numy]);
    
    % change NaNs to -inf (usually this is from: inf-inf)
    iinn = find(isnan(lpg));
    if ~isempty(iinn)
      lpg(iinn) = -inf;
      nanwarn = nanwarn + length(iinn);
    end
    % change +inf to -inf (more instabilities)
    % in general we should not have log(p) = inf
    iinn = find(isinf(lpg) .* (lpg>0));
    if ~isempty(iinn)
      lpg(iinn) = -inf;
      pinfwarn = pinfwarn+length(iinn);
    end
    
    fun_value = exp(lpg);
    
    MM = Mdelta ./ Mstd;
    
    % logp(eta) * Normal(eta|m,v)
    MlogpN = bsxfun(@times, fun_value, N_standard);
    lZ(idexN, i)  = log(sum(MlogpN,2) .* MM);

    % check for lZ == -inf
    ii = find(isinf(lZ(idexN, i)));
    if ~isempty(ii)
      % lpg is too small, so try logtrick
      tmp1 = bsxfun(@plus, lpg(ii,:), logN_standard);
      tmp2 = logtrick(tmp1')';
      lZ(idexN(ii), i) =  tmp2 + log(MM(ii));
      infwarn = infwarn + length(ii);
    end
    
    if (any(isnan(lZ(i,:))))
      % NaN value means fun_value is too small or lpg is bad
      % or lp = inf-inf ~= -inf
      warning('NaN value in lpg or lZ');
      keyboard
      %ii = find(isnan(lZ));
      %lZ(ii) = -inf;
    end
    
    if (nargout>1)
      % moment computations cannot handle more than one y per test point
      % in general, this is not currently needed.
      if (numy ~= 1)
	error('cannot compute moments for more than 1 y!')
      end      
      
      % mean of q      
      lq = lpg - repmat(lZ(idexN, i), [1 NUMPOINTS]); % log q
      fun_value = Meta.*exp(lq);
      MlogpN = bsxfun(@times, fun_value, N_standard);
      mu_moment(idexN, i)  = sum(MlogpN,2) .* MM;
      
      % variance of q
      if (nargout>2)
	   fun_value = (Meta-repmat(mu_moment(idexN, i), [1 NUMPOINTS])).^2 .* exp(lq);
       MlogpN = bsxfun(@times, fun_value, N_standard);
	   var_moment(idexN, i) = sum(MlogpN,2) .* MM;
      end
    end
  end

end

if (nanwarn > 0)
  fprintf('warning EPmomentsNumInt: lpg: replaced %d NaNs with -infs\n', nanwarn);
end
if (pinfwarn > 0)
  fprintf('warning EPmomentsNumInt: lpg: replaced %d inf with -infs\n', ...
	  pinfwarn);
end
if (infwarn > 0)
  fprintf('warning EPmomentsNumInt: lZ: used log-trick %d times\n', infwarn);
end

if (nargout>1) && any(isnan(mu_moment)) 
  warning('NaN mu');
  keyboard
end
if (nargout>2) && any(isnan(var_moment)) 
  warning('NaN var');
  keyboard
end

if 0
  toc
  tic
  % test quad
  if nargout == 1
    [qlZ] = EPmomentsQuad(lf, y, mu, s2);  
  elseif nargout == 2
    [qlZ, qmu_moment] = EPmomentsQuad(lf, y, mu, s2);
  elseif nargout == 3
    [qlZ, qmu_moment, qvar_moment] = EPmomentsQuad(lf, y, mu, s2);
  end
  toc
  
  if nargout>2
    foo = qvar_moment-var_moment;   
    fprintf('qerr_var = %g; ', mean(abs(foo(:))));
    fprintf('max err = %g; ', max(abs(foo(:))));
    fprintf('max %%err = %g;\n', max(abs(foo(:)./var_moment(:))));
  end
  if nargout>1
    foo = qmu_moment-mu_moment;
    fprintf('qerr_mu = %g; ', mean(abs(foo(:))));
    fprintf('max err = %g; ', max(abs(foo(:))));
    fprintf('max %%err = %g;\n', max(abs(foo(:)./mu_moment(:))));
  end
  foo = lZ-qlZ;   
  fprintf('qerr_lZ = %g; ', mean(abs(foo(:))));
  fprintf('max err = %g; ', max(abs(foo(:))));
  fprintf('max %%err = %g;\n', max(abs(foo(:)./lZ(:))));
  keyboard
end
