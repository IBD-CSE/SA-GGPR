function [ymu, ys2] = pred_dist_unscented(lf, y, mu, s2);
% pred_dist_unscented -- predictive distribution statistics using unscented transform
%
% Computes the mean and variance of the predictive distribution
% using the unscented transform.
%
%  not really correct, but the best we can do without computing the preditive distribution
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27


ymu = {};
ys2 = {};

%ymu = lf.db(lf.theta(mu));

% predicted Y mean is the mean of f(x) projected into Y space
% (using unscented transform)
%
% i.e.
%  p(y) = \int p(y|eta) p(eta) deta
%  E[y] = \int \int y p(y|eta) p(eta) deta dy
%      \approx  (1/3) \sum_s \int y p(y|eta_s) dy
%             = (1/3) \sum_s E(y|eta_s)
%      
%     where eta_s are the control points (mean +- std)
%
%tmps = sqrt(s2)*sqrt(3)/2;  % actual unscented

% use std points to make it consistent for gaussians
tmps = sqrt(s2);            
etas = [mu, mu-tmps, mu+tmps];  % control points
      
% compute E(y|eta_s)
Ey_etas = lf.db(lf.theta(etas));

% compute var(y|eta_s)
vary_etas = lf.a()*lf.d2b(lf.theta(etas));   % variance from likelihood      

if isfield(lf, 'T')
  % special case: using T(y)
  %Ey_etas = lf.Tinv(Ey_etas);
  %ymu = mean(Ey_etas,2);
  
  % what we computed was actually E[T(y)|etas] and var[T(y)|etas]
  ETy_etas   = Ey_etas;
  varTy_etas = vary_etas;
  
  % unscented approximation:  T(y)|etas ~ N(E[y|etas] | var(y|etas))
  %    --> E[y|etas] = E(Tinv(T(y))|etas) \approx mean( Tinv(Teta_s) )
  %    --> var(y|etas) = var(Tinv(T(y))|etas) \approx var(Tinv(Teta_s))
  % where Tetas_s are control points from N(E[y|etas] | var(y|etas))
  for ii=1:3
    tmp = sqrt(varTy_etas(:,ii));
    Tetas = [ETy_etas(:,ii), ETy_etas(:,ii)-tmp, ETy_etas(:,ii)+tmp];
    Ey_etas(:,ii)   = mean(lf.Tinv(Tetas), 2);
    vary_etas(:,ii) = var(lf.Tinv(Tetas), 0, 2);
    % use unbiased variance to match when Ty=y
  end
end
      
% compute mean: E[y] = mean( E(y|eta_s) )
ymu = mean(Ey_etas,2);	
      
if nargout>1
  if 0 % OLD METHOD
       % predicted Y variance has two parts
       %   1) variance of gaussian  projected into Y space (parameter uncertainty)
       %        this is estimated with the unscented transform.
       %   2) the variance of p(y|eta) at eta=mu (observation noise)	
       ys2_g  = var(Ey_etas,0,2);
       ys2_sn = lf.a()*lf.d2b(lf.theta(mu));
       
       ys2_old = ys2_g + ys2_sn;
  end
  
  % var(y) = \int \int (y-E[y])^2 p(y|eta)p(eta)deta dy
  %       \approx (1/3) \sum_s \int (y-E[y])^2 p(y|eta_s) dy
  %             = (1/3) \sum_s \int (y-E[y|eta_s]+E[y|eta_s]-E[y])^2 p(y|\eta_s) dy
  %             = (1/3) \sum_s var(y|\eta_s) + (E[y|eta_s)-E[y])^2
  
  Ey_y_etas = (Ey_etas - repmat(ymu,1,3)).^2;  % variance from posterior
  
  m_vary_etas = mean(vary_etas,2);    % standard mean
  m_Ey_y_etas = sum(Ey_y_etas,2)/(2); % use unbiased mean
				      % (makes the approximation exact for likExGauss)
					
  ys2 = m_vary_etas + m_Ey_y_etas;
	
  if 0
    % check
    figure(999)
    subplot(3,1,1)
    plot(etas);
    grid
    title('eta_s')
    subplot(3,1,2)
    plot(Ey_etas);
    hold on
    plot(ymu, 'k--');
    hold off
    grid
    title('E[y|eta_s]')
    subplot(3,1,3)
    plot(sqrt(vary_etas), 'b-');  % same as ys2_g
    hold on
    plot(sqrt(Ey_y_etas), 'r-');
    plot(sqrt(ys2_old), 'g-')
    plot(sqrt(ys2), 'k--');
    hold off
    grid
    title('std(y)')
    keyboard
  end
  
end

