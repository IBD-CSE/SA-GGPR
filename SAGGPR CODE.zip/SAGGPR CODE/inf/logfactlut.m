function [lf] = logfactlut(y)
% logfactlut - log factorial lookup table
%
%   [lf] = logfactlut(y)
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27


% lookup table: logfact_lut(y+1) = y!
persistent logfact_lut

maxy = max(y(:));

% recompute if too small or first time
if isempty(logfact_lut) || (length(logfact_lut)<maxy+1)
  % log 0! = 0
  logfact_lut(1) = 0;
  
  if isempty(logfact_lut)
    maxy = 500;
  else
    maxy = 2*maxy+1;
  end
  
  % log y! = sum(log(1:y))
  logfact_lut(2:maxy+1) = cumsum(log(1:maxy));
end

lf = logfact_lut(y+1);

% rotate if column vector
if (size(y,2) == 1)
  lf = lf';
end
