function lf = likExPoisson(hyp)
% Poisson likelihood function
%   y in {0,1,2,3,...}
%
% Generalized Gaussian Process Models Toolbox (GPML Add-on)
% Copyright (c) by Antoni B. Chan, 2013-11-27

% TODO: make c a hyperparameter?


% return number of likelihood parameters
if nargin<1, lf = 0; return; end

%%% check y %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lf.chky    = @(y) checkY(y);

%%% setup Gaussian %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lf.a       = @() 1;
lf.da      = @() 0;
lf.b       = @(theta) exp(theta);
lf.db      = @(theta) exp(theta);
lf.d2b     = @(theta) exp(theta);
lf.d3b     = @(theta) exp(theta);
lf.lh      = @(y) -logfactlut(y);     % BUG:  1 - gammaln(y+1);
lf.dlh     = @(y) zeros(size(y));
lf.theta   = @(eta) eta;
lf.dtheta  = @(eta) ones(size(eta));
lf.d2theta = @(eta) zeros(size(eta));
lf.d3theta = @(eta) zeros(size(eta));
lf.fix_phi = 1;         % no dispersion parameter, so force fixed for speed


%%% Taylor approximation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c = 0.001;
c  = 1;
lf.etahat  = @(y) log(y+c);

%%% EP - Conjugate Prior %%%%
lf.pb     = @(theta) exp(theta);
lf.pdb    = @(theta) exp(theta);
lf.pd2b   = @(theta) exp(theta);
lf.pd3b   = @(theta) exp(theta);
lf.ptheta = @(eta) eta;
lf.pH     = @(gammaV, psiV) 1 ./ gamma(gammaV./psiV) .* ((psiV).^(-gammaV./psiV));
lf.plH    = @(gammaV, psiV) - gammaln(gammaV./psiV) - gammaV./psiV.*log(psiV);

lf.EstWithGauss = @(mu, s2)EstWithGauss(mu, s2); 

%%% KL approximation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lf.custom_KL = 1;   % flag of the custom derivative, 1 use custon derivative, else compute moments in generic fun
lf.dm      = @(m,v,y) y - exp(mu+s2/2);
lf.d2m     = @(m,v,y) -exp(mu+s2/2)/2;
lf.dv      = @(m,v,y) exp(mu+s2/2); 
lf.d2v     = @(m,v,y) (1/4+1./(2*s2)).*exp(mu+s2/2);
lf.dmv     = @(m,v,y) exp(mu+s2/2)/2;
lf.el      = @(m,v,y) y.*mu - exp(mu+s2/2) - logfactlut(y);

% expecation for theta and b
lf.etheta  = @(m,v) m;
lf.eb      = @(m,v) exp(m+v/2);

function ycheck = checkY(y)
 ycheck = max(floor(y), 0);  % round and truncate
 if any(y ~= ycheck)
 % error('y contains non-counting numbers!'); % removed for demo experiments
 end

function [gammaV, psiV] = EstWithGauss(mu, s2)
  gammaV = exp(mu);
  psiV = exp(mu) .* s2;